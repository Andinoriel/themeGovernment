<?php
class TicketDataManagerController extends ResourceDataManagerController {}