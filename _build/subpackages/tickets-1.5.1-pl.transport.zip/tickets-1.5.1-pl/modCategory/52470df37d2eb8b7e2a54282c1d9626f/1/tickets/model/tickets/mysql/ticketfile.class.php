<?php
require_once (dirname(dirname(__FILE__)) . '/ticketfile.class.php');
class TicketFile_mysql extends TicketFile {}