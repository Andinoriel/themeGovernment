<?php
require_once (dirname(dirname(__FILE__)) . '/ticketthread.class.php');
class TicketThread_mysql extends TicketThread {}